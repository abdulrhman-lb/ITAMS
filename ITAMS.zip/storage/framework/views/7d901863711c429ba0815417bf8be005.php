

<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
    <div class="container alert alert-warning" role="alert">
        <?php echo e(session()->get('message')); ?>

    </div> 
<?php endif; ?>
    <div class="container">
        <h5 class="d-flex fw-bold justify-content-center pb-3">قائمة الموديلات </h5>
        <table class="table table-bordered">
            <tr>
                <th class="centered-content">#</th>
                <th class="centered-content">صورة</th>
                <th class="centered-content">التصنيف</th>
                <th class="centered-content">الموديلات وتعني HP ProBook G2 - Lenovo 81HN - سكنر .... الخ</th>
                <th class="centered-content" colspan="2"><a href="/const/model/create"><button type="button" class="btn btn-dark my-1">إضافة جديدة  <i class="fa fa-plus-square"></i></button></a></th>	
            </tr>
            <?php
                $count = 0;
            ?>
            <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                <?php
                    $count++;
                    $image = '';
                    if (($model -> image) == '' ) {
                        $image = 'model/non.png';
                    } else {
                        $image = 'model/' . $model -> image; 
                    }
                ?>         
                <tr class="pt-3 ">
                    <td class="fw-bold centered-content"><?php echo e($count); ?></td>
                    <td class="fw-bold centered-content">
                        <a href="/images/<?php echo e($image); ?>" data-lightbox="post-image" data-title="<?php echo e($model -> model); ?>">
                            <img src="/images/<?php echo e($image); ?>" alt="<?php echo e($model -> model); ?>" class="thumbnail img-pro-show"">
                        </a>
                    </td>
                    <td class="centered-content"><?php echo e($model -> category -> category); ?></td>
                    <td class="centered-content"><?php echo e($model -> model); ?></td>
                    <td class="centered-content">
                    <form action="/const/model/<?php echo e($model -> id); ?>" method="POST">   
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("DELETE"); ?>
                        <a href="/const/model/<?php echo e($model -> id); ?>/edit"><button type="button" class="btn btn-secondary my-1"><i class="fa fa-edit"></i></button></a>
                        <button type="submit" class="btn btn-secondary my-1" onclick ="return confirm('هل تريد بالتأكيد حذف هذا الموديل ؟')"><i class="fa fa-trash"></i></button>  
                    </form>  
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\ITAMS\resources\views/const/model/index.blade.php ENDPATH**/ ?>