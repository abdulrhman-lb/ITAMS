<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
    <div class="container alert alert-warning" role="alert">
        <?php echo e(session()->get('message')); ?>

    </div> 
<?php endif; ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header text-center p-4 fw-bold"><?php echo e($devices -> model -> model); ?></div>
                    <?php
                        $image = '';
                        if (($devices -> model -> image) == '' ) {
                            $image = 'model/non.png';
                        } else {
                            $image = 'model/' . $devices -> model -> image; 
                        }
                    ?> 
                    <div class="card mb-3" style="max-width: 100%; max-height: 100%">
                        <div class="row g-0">
                          <div class="col-md-4 p-3">
                            <a href="/images/<?php echo e($image); ?>" data-lightbox="post-image" data-title="<?php echo e($devices -> model -> model); ?>">
                                <img src="/images/<?php echo e($image); ?>" alt="<?php echo e($devices -> model -> model); ?>" class="thumbnail img-fluid rounded-start">
                            </a>
                          </div>
                          <div class="col-md-8">
                            <div class="card-body">
                                <?php
                                    if (is_null($devices -> processor)) {
                                        $processor = '-';
                                    } else {
                                        $processor = $devices -> processor -> processor;
                                    }

                                    if (is_null($devices -> memory1)) {
                                        $memory1 = '-';
                                    } else {
                                        $memory1 = $devices -> memory1 -> kind . ' - ' . $devices -> memory1 -> size;
                                    }
                                    
                                    if (is_null($devices -> memory2)) {
                                        $memory2 = '-';
                                    } else {
                                        $memory2 = $devices -> memory2 -> kind . ' - ' . $devices -> memory2 -> size;
                                    }

                                    if (is_null($devices -> hard_disk1)) {
                                        $hard_disk1 = '-';
                                    } else {
                                        $hard_disk1 = $devices -> hard_disk1 -> kind . ' - ' . $devices -> hard_disk1 -> size;
                                    }

                                    if (is_null($devices -> hard_disk2)) {
                                        $hard_disk2 = '-';
                                    } else {
                                        $hard_disk2 = $devices -> hard_disk2 -> kind . ' - ' . $devices -> hard_disk2 -> size;
                                    }
                                    
                                    if (is_null($devices -> employee)) {
                                        $full_name = ' - ';
                                        $sub_branch = ' - ';
                                        $department = ' - ';
                                    } else {
                                        $full_name = $devices -> employee -> full_name;
                                        $sub_branch = $devices -> employee -> sub_branch -> sub_branch;
                                        $department = $devices -> employee -> department -> department;
                                    }
                                ?>
                                <table class="table table-bordered">
                                    <tr>
                                        <td class="fw-bold centered-content">الفرع</td>
                                        <td class="centered-content" colspan="2"><?php echo e($devices -> branch -> branch); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold centered-content">الصنف</td>
                                        <td class="centered-content" colspan="2"><?php echo e($devices -> class -> class); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold centered-content">التصنيف</td>
                                        <td class="centered-content" colspan="2"><?php echo e($devices -> category -> category); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold centered-content">الموديل</td>
                                        <td class="centered-content" colspan="2"><?php echo e($devices -> model -> model); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold centered-content" >الحالة الفنية</td>
                                        <td class="centered-content" colspan="2"><?php echo e($devices -> status -> status); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold centered-content">المحلقات</td>
                                        <td class="centered-content" colspan="2"><?php echo e($devices -> accossories); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold centered-content">المعالج</td>
                                        <td class="centered-content" colspan="2"><?php echo e($processor); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold centered-content">الذاكرة</td>
                                        <td class="centered-content"><?php echo e($memory1); ?></td>
                                        <td class="centered-content"><?php echo e($memory2); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold centered-content">الهارد</td>
                                        <td class="centered-content"><?php echo e($hard_disk1); ?></td>
                                        <td class="centered-content"><?php echo e($hard_disk1); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold centered-content">ملاحظات</td>
                                        <td class="centered-content" colspan="2"><?php echo e($devices -> notes); ?></td>
                                    </tr>
                                </table>
                                <table class="table table-bordered">
                                    <tr>
                                        <td class="fw-bold centered-content">اسم المستلم</td>
                                        <td class="centered-content"><?php echo e($full_name); ?></td>
                                    </tr>

                                    <tr>
                                        <td class="fw-bold centered-content">الشعبة</td>
                                        <td class="centered-content"><?php echo e($sub_branch); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold centered-content">القسم</td>
                                        <td class="centered-content"><?php echo e($department); ?></td>
                                    </tr>
                                </table>
                            </div>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
  <div class="text-center ">
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\ITAMS\resources\views/device/show.blade.php ENDPATH**/ ?>