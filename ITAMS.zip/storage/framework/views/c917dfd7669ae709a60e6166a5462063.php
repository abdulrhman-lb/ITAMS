
<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
    <div class="container alert alert-warning" role="alert">
        <?php echo e(session()->get('message')); ?>

    </div> 
<?php endif; ?>
    <div class="container">
        <h5 class="d-flex fw-bold justify-content-center pb-3">قائمة الحالة الفنية </h5>
        <table class="table table-bordered">
            <tr>
                <th class="centered-content">#</th>
                <th class="centered-content">الحالة الفنية للأجهزة</th>
                <th class="centered-content" colspan="2"><a href="/const/status/create"><button type="button" class="btn btn-dark my-1">إضافة جديدة  <i class="fa fa-plus-square"></i></button></a></th>
            </tr>
            <?php
                $count = 0;
            ?>
            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
                <tr class="pt-3 ">
                    <?php
                        $count++;
                    ?>
                    <td class="fw-bold centered-content"><?php echo e($count); ?></td>
                    <td class="centered-content"><?php echo e($status -> status); ?></td>
                    <td class="centered-content">
                        <form action="/const/status/<?php echo e($status -> id); ?>" method="POST">   
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("DELETE"); ?>
                            <a href="/const/status/<?php echo e($status -> id); ?>/edit"><button type="button" class="btn btn-secondary my-1"><i class="fa fa-edit"></i></button></a>
                            <button type="submit" class="btn btn-secondary my-1" onclick ="return confirm('هل تريد بالتأكيد حذف هذا التوصيف الوظيفي ؟')"><i class="fa fa-trash"></i></button>  
                        </form>  
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\ITAMS\resources\views/const/status/index.blade.php ENDPATH**/ ?>