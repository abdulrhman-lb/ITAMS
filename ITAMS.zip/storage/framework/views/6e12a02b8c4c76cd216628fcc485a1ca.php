

<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
    <div class="container alert alert-warning" role="alert">
        <?php echo e(session()->get('message')); ?>

    </div> 
<?php endif; ?>
    <div class="container">
        <h5 class="d-flex fw-bold justify-content-center pb-3">قائمة المستخدمين </h5>
        <table class="table table-bordered">
            <tr>
                <th class="centered-content">#</th>
                <th class="centered-content">اسم المستخدم</th>
                <th class="centered-content">البريد الالكتروني</th>
                <th class="centered-content">الفعالية</th>
                <th class="centered-content">السماحيات</th>
                <th class="centered-content" colspan="2"></th>
            </tr>
            <?php
                $count = 0;
            ?>
            <?php $__currentLoopData = $User; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
                <tr class="pt-3 ">
                    <?php
                        $count++;
                    ?>
                    <td class="fw-bold centered-content"><?php echo e($count); ?></td>
                    <td class="centered-content <?php echo e($user -> active == '0' ? 'text-danger' : ''); ?>"><?php echo e($user -> name); ?></td>
                    <td class="centered-content <?php echo e($user -> active == '0' ? 'text-danger' : ''); ?>"><?php echo e($user -> email); ?></td>
                    <td class="centered-content <?php echo e($user -> active == '0' ? 'text-danger' : ''); ?>"><?php echo e($user -> active == '1' ? 'فعال' : 'غير فعال'); ?></td>
                    <td class="centered-content <?php echo e($user -> active == '0' ? 'text-danger' : ''); ?>"><?php echo e(($user -> role == '1' ? 'مدير' : 'مستخدم عادي : فرع ' . (is_null($user -> branch_id) ? 'غير مخصص' : $user -> branch -> branch))); ?></td>
                    <td class="centered-content">
                        <a href="/user/<?php echo e($user -> id); ?>/edit"><button type="button" class="btn btn-success my-1"><i class="fa fa-edit"></i></button></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\ITAMS\resources\views/User/index.blade.php ENDPATH**/ ?>