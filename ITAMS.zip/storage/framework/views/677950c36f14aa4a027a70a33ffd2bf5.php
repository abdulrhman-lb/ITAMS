

<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
    <div class="container alert alert-warning" role="alert">
        <?php echo e(session()->get('message')); ?>

    </div> 
<?php endif; ?>
    <div class="container">
        <h5 class="d-flex fw-bold justify-content-center pb-3">قائمة الأقسام </h5>
        <table class="table table-bordered">
            <tr>
                <th class="centered-content">#</th>
                <th class="centered-content">اسم القسم باللغة العربية</th>
                <th class="centered-content">اسم القسم باللغة الانكليزية</th>
                <th class="centered-content" colspan="2"><a href="/const/department/create"><button type="button" class="btn btn-dark my-1">إضافة جديدة  <i class="fa fa-plus-square"></i></button></a></th>	
            </tr>
            <?php
                $count = 0;
            ?>
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
                <tr class="pt-3 ">
                    <?php
                        $count++;
                    ?>
                    <td class="fw-bold centered-content"><?php echo e($count); ?></td>
                    <td class="centered-content"><?php echo e($department -> department); ?></td>
                    <td class="centered-content"><?php echo e($department -> department_en); ?></td>
                    <td class="centered-content">
                        <form action="/const/department/<?php echo e($department -> id); ?>" method="POST">   
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("DELETE"); ?>
                            <a href="/const/department/<?php echo e($department -> id); ?>/edit"><button type="button" class="btn btn-secondary my-1"><i class="fa fa-edit"></i></button></a>
                            <button type="submit" class="btn btn-secondary my-1" onclick ="return confirm('هل تريد بالتأكيد حذف هذا القسم ؟')"><i class="fa fa-trash"></i></button>  
                        </form>  
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\ITAMS\resources\views/const/department/index.blade.php ENDPATH**/ ?>