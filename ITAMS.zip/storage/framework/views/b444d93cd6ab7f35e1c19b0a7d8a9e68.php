

<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
    <div class="container alert alert-warning" role="alert">
        <?php echo e(session()->get('message')); ?>

    </div> 
<?php endif; ?>
<div class="container">
    <div class="row justify-content-center mb-3">
        <form action="<?php echo e(route('employee_search')); ?>" method="post">   
            <?php echo csrf_field(); ?>
            <div class="accordion" id="accordionPanelsStayOpenExample">
                <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
                    <div class="fw-bold text-center">قائمة الموظفين <?php echo e(' - ' . (Auth::user()->role == '1'  ? 'كل الفروع' : 'فرع ' . Auth::user()->branch->branch)); ?></div>
                </button>
                </h2>
                <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse">
                    <div class="accordion-body">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row text-center">
                                        
                                        <div class="col-3">
                                            <div class="row mb-3">
                                                <label for="branch_id" class="col-md-4 col-form-label text-center">الفرع</label>
                                                <div class="col-md-8">
                                                    <select class="form-select" id="branch_id" name="branch_id">
                                                        <option value="">-</option>
                                                        <?php $__currentLoopData = $list['branches']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($branch -> id); ?>" <?php echo e($branch -> id == $list['search_branch'] ? 'selected' : ''); ?>><?php echo e($branch -> branch); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
            
                                        <div class="col-3">
                                            <div class="row mb-3">
                                                <label for="sub_branch_id" class="col-md-4 col-form-label text-md-start">الشعبة</label>
                                                <div class="col-md-8">
                                                    <select class="form-select" id="sub_branch_id" name="sub_branch_id">
                                                        <option value="">-</option>
                                                        <?php $__currentLoopData = $list['sub_branches']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($sub_branch -> id); ?>" <?php echo e($sub_branch -> id == $list['search_sub_branch'] ? 'selected' : ''); ?>><?php echo e($sub_branch -> sub_branch .  ' - ' . $sub_branch -> sub_branch_en); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-3">
                                            <div class="row mb-3">
                                                <label for="department_id" class="col-md-4 col-form-label text-md-start">القسم</label>
                                                <div class="col-md-8">
                                                    <select class="form-select" id="department_id" name="department_id">
                                                        <option value="">-</option>
                                                        <?php $__currentLoopData = $list['departments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($department -> id); ?>" <?php echo e($department -> id == $list['search_department'] ? 'selected' : ''); ?>><?php echo e($department -> department); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-3">
                                            <div class="row mb-3">
                                                <label for="full_name" class="col-md-4 col-form-label text-md-start">الاسم</label>
                                                <div class="col-md-8">
                                                    <input id="full_name" type="text" class="form-control" name="full_name" value="<?php echo e($list['search_full_name']); ?>">
                                                </div>
                                            </div>
                                        </div>
            

                                        <div class="col-5">
                                            <div class="row mb-3">
                                                <div class="col-md-6 offset-md-5">
                                                    <button type="submit" name="search" id="search" class="btn btn-dark" style="width: 100%">تصفية</button>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-5">
                                            <div class="row mb-3">
                                                <div class="col-md-6 offset-md-5">
                                                    <button type="submit" name="clear" id="cancel" class="btn btn-dark" style="width: 100%" >مسح</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div class="row justify-content-center mb-3 mt-3">
        <table class="table table-bordered">
            <tr>
                <th class="centered-content">#</th>
                <th class="centered-content">الفرع</th>
                <th class="centered-content">الشعبة</th>
                <th class="centered-content">القسم</th>
                <th class="centered-content">اسم الموظف</th>
                <th class="centered-content">المسمى الوظيفي</th>
                <th class="centered-content">رقم الهاتف</th>
                <th class="centered-content">رقم الموبايل</th>
                <th class="centered-content">البريد الالكتروني</th>
                <th class="centered-content" colspan="2"><a href="employee/create"><button type="button" class="btn btn-dark my-1">إضافة جديدة  <i class="fa fa-plus-square"></i></button></a></th>	
            </tr>
            <?php
                $count = 0;
            ?>
            <?php $__currentLoopData = $list['employees']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
                <tr class="pt-3 ">
                    <?php
                        $count++;
                    ?>
                    <td class="fw-bold centered-content"><?php echo e($count); ?></td>
                    <td class="centered-content <?php echo e($employee -> ena === '0' ? 'text-danger' : ''); ?>"><?php echo e($employee -> branch -> branch); ?></td>
                    <td class="centered-content <?php echo e($employee -> ena == '0' ? 'text-danger' : ''); ?>"><?php echo e($employee -> sub_branch -> sub_branch); ?></td>
                    <td class="centered-content <?php echo e($employee -> ena == '0' ? 'text-danger' : ''); ?>"><?php echo e($employee -> department -> department); ?></td>
                    <td class="centered-content <?php echo e($employee -> ena == '0' ? 'text-danger' : ''); ?>"><?php echo e($employee -> full_name); ?></td>
                    <td class="centered-content <?php echo e($employee -> ena == '0' ? 'text-danger' : ''); ?>"><?php echo e($employee -> jop_title -> jop_title); ?></td>
                    <td class="centered-content <?php echo e($employee -> ena == '0' ? 'text-danger' : ''); ?>"><?php echo e($employee -> phone); ?></td>
                    <td class="centered-content <?php echo e($employee -> ena == '0' ? 'text-danger' : ''); ?>"><?php echo e($employee -> mobile); ?></td>
                    <td class="centered-content <?php echo e($employee -> ena == '0' ? 'text-danger' : ''); ?>"><?php echo e($employee -> email); ?></td>
                    <td class="centered-content">
                    <form action="/employee/<?php echo e($employee -> id); ?>" method="POST">   
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("DELETE"); ?>
                        <a href="/employee/<?php echo e($employee -> id); ?>/edit"><button type="button" class="btn btn-secondary my-1"><i class="fa fa-edit"></i></button></a>
                        <button type="submit" class="btn btn-secondary my-1" onclick ="return confirm('هل تريد بالتأكيد حذف هذا الموظف ؟')"><i class="fa fa-trash"></i></button>  
                        <a href="<?php echo e(route('device-employee','id='.$employee -> id)); ?>"><button type="button" title="استلام وتسليم" class="btn btn-secondary my-1 notification"><i class="fa fa-retweet"></i><span class="badge"><?php echo e($employee -> devices_count); ?></span></button></a>
                    </form>  
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\ITAMS\resources\views/employee/index.blade.php ENDPATH**/ ?>