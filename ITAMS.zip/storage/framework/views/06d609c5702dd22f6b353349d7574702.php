

<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
    <div class="container alert alert-warning" role="alert">
        <?php echo e(session()->get('message')); ?>

    </div> 
<?php endif; ?>
    <div class="container">
        <h5 class="d-flex fw-bold justify-content-center pb-3">قائمة الفروع </h5>
        <table class="table table-bordered">
            <tr>
                <th class="centered-content">#</th>
                <th class="centered-content">اسم الفرع باللغة العربية</th>
                <th class="centered-content">اسم الفرع باللغة الانكليزية</th>
                <th class="centered-content" colspan="2"><a href="/const/branch/create"><button type="button" class="btn btn-dark my-1">إضافة جديدة  <i class="fa fa-plus-square"></i></button></a></th>	
            </tr>
            <?php
                $count = 0;
            ?>
            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
                <tr class="pt-3 ">
                    <?php
                        $count++;
                    ?>
                    <td class="fw-bold centered-content"><?php echo e($count); ?></td>
                    <td class="centered-content"><?php echo e($branch -> branch); ?></td>
                    <td class="centered-content"><?php echo e($branch -> branch_en); ?></td>
                    <td class="centered-content">
                        <form action="/const/branch/<?php echo e($branch -> id); ?>" method="POST">   
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("DELETE"); ?>
                            <a href="/const/branch/<?php echo e($branch -> id); ?>/edit"><button type="button" class="btn btn-secondary my-1"><i class="fa fa-edit"></i></button></a>
                            <button type="submit" class="btn btn-secondary my-1" onclick ="return confirm('هل تريد بالتأكيد حذف هذا الفرع ؟')"><i class="fa fa-trash"></i></button>  
                        </form>  
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\ITAMS\resources\views/const/branch/index.blade.php ENDPATH**/ ?>