

<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
    <div class="container alert alert-warning" role="alert">
        <?php echo e(session()->get('message')); ?>

    </div> 
<?php endif; ?>

<div class="container">
    <div class="row justify-content-center pb-2">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header text-center fw-bold">
                    تنقلات الجهاز المحدد - الاستلام والتسليم
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-8">

                            <div class="row mb-3">
                                <div class="col-3"><label for="branch_id" class="col-md-12 col-form-label text-center">التصنيف</label></div>
                                <div class="col-3"><label for="branch_id" class="col-md-12 col-form-label text-center">الصنف</label></div>
                                <div class="col-3"><label for="branch_id" class="col-md-12 col-form-label text-center">الموديل</label></div>
                                <div class="col-3"><label for="branch_id" class="col-md-12 col-form-label text-center">الرقم المتسلسل</label></div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-3 fw-bold"><label for="branch_id" class="col-md-12 col-form-label text-center"><?php echo e($list['devices'] -> class -> class); ?></label></div>
                                <div class="col-3 fw-bold"><label for="branch_id" class="col-md-12 col-form-label text-center"><?php echo e($list['devices'] -> category -> category); ?></label></div>
                                <div class="col-3 fw-bold"><label for="branch_id" class="col-md-12 col-form-label text-center"><?php echo e($list['devices'] -> model -> model); ?></label></div>
                                <div class="col-3 fw-bold"><label for="branch_id" class="col-md-12 col-form-label text-center"><?php echo e($list['devices'] -> serial_number); ?></label></div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-3"><label for="branch_id" class="col-md-12 col-form-label text-center">الحالة الفنية</label></div>
                                <div class="col-3"><label for="branch_id" class="col-md-12 col-form-label text-center">اسم المستلم</label></div>
                                <div class="col-3"><label for="branch_id" class="col-md-12 col-form-label text-center">الفرع</label></div>
                                <div class="col-3"><label for="branch_id" class="col-md-12 col-form-label text-center">القسم</label></div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-3 fw-bold"><label for="branch_id" class="col-md-12 col-form-label text-center"><?php echo e($list['devices'] -> status -> status); ?></label></div>
                                <div class="col-3 fw-bold"><label for="branch_id" class="col-md-12 col-form-label text-center"><?php echo e(is_null($list['devices'] -> employee) ? ' - ' : $list['devices'] -> employee -> full_name); ?></label></div>
                                <div class="col-3 fw-bold"><label for="branch_id" class="col-md-12 col-form-label text-center"><?php echo e($list['devices'] -> branch -> branch); ?></label></div>
                                <div class="col-3 fw-bold"><label for="branch_id" class="col-md-12 col-form-label text-center"><?php echo e(is_null($list['devices'] -> employee) ? ' - ' : $list['devices'] -> employee -> department -> department); ?></label></div>
                            </div>
                        </div>

                        <div class="col-4">
                            <div class="row mb-3">

                                <?php
                                $image = '';
                                    if (($list['devices'] -> model -> image) == '' ) {
                                        $image = 'model/non.png';
                                    } else {
                                        $image = 'model/' . $list['devices'] -> model -> image; 
                                    }
                                ?> 
                                <a href="/images/<?php echo e($image); ?>" data-lightbox="post-image" data-title="<?php echo e($list['devices'] -> model -> model); ?>">
                                    <img src="/images/<?php echo e($image); ?>" alt="<?php echo e($list['devices'] -> model -> model); ?>" class="img-pro-show-box">
                                </a>

                            </div>
                            <form action="<?php echo e(route('dates-add')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="device_id" value="<?php echo e($list['devices'] -> id); ?>">
                                <input type="hidden" name="back" value="<?php echo e($list['back']); ?>">
                                <div class="row mb-3">
                                    <select class="form-select <?php $__errorArgs = ['employee_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="employee_id" name="employee_id">
                                        <option value="" selected>اختر الموظف الذي تريد نقل الجهاز له ...</option>
                                        <?php $__currentLoopData = $list['employees']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($employee -> id); ?>"><?php echo e($employee -> full_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['employee_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="row mb-3">
                                    <button type="submit" name="change" class="btn btn-dark">نقل الجهاز إلى الموظف المحدد     <i class="fa fa-braille"></i></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <table class="table table-bordered">
        <tr>
            <th class="centered-content">#</th>
            <th class="centered-content">اسم الموظف</th>
            <th class="centered-content">الفرع</th>
            <th class="centered-content">الشعبة</th>
            <th class="centered-content">القسم</th>
            <th class="centered-content">تاريخ الاستلام</th>
            <th class="centered-content">تاريخ التسليم</th>
        </tr>
        <?php
            $count = 0;
        ?>
        <?php $__currentLoopData = $list['dates']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dates): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
            <tr class="pt-3 ">
                <?php
                    $count++;
                ?>
                <td class="fw-bold centered-content"><?php echo e($count); ?></td>
                <td class="centered-content"><?php echo e($dates -> employee -> full_name); ?></td>
                <td class="centered-content"><?php echo e($dates -> branch -> branch); ?></td>
                <td class="centered-content"><?php echo e($dates -> sub_branch -> sub_branch); ?></td>
                <td class="centered-content"><?php echo e($dates -> department -> department); ?></td>
                <td class="centered-content"><?php echo e($dates -> start_date); ?></td>
                <td class="centered-content"><?php echo e($dates -> end_date); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <form action="<?php echo e(route('export-dates',$list['devices'] -> id)); ?>" method="get">
        <?php echo csrf_field(); ?>
        <div class="row mb-3 text-center" style="justify-content: center;">
            <input type="hidden" name="device_id" value="<?php echo e($list['devices'] -> id); ?>">
            <input type="hidden" name="class" value="<?php echo e($list['devices'] -> class -> class); ?>">
            <input type="hidden" name="category" value="<?php echo e($list['devices'] -> category -> category); ?>">
            <input type="hidden" name="model" value="<?php echo e($list['devices'] -> model -> model); ?>">
            <input type="hidden" name="status" value="<?php echo e($list['devices'] -> status -> status); ?>">
            <input type="hidden" name="serial_number" value="<?php echo e($list['devices'] -> serial_number); ?>">

            <?php if(!is_null($list['devices'] -> employee)): ?>
                <input type="hidden" name="employee" value="<?php echo e($list['devices'] -> employee -> full_name); ?>">
                <input type="hidden" name="branch" value="<?php echo e($list['devices'] -> employee -> branch -> branch); ?>">
                <input type="hidden" name="sub_branch" value="<?php echo e($list['devices'] -> employee -> sub_branch -> sub_branch); ?>">
                <input type="hidden" name="department" value="<?php echo e($list['devices'] -> employee -> department -> department); ?>">
                <input type="hidden" name="jop_title" value="<?php echo e($list['devices'] -> employee -> jop_title -> jop_title); ?>">
            <?php endif; ?>
            
            <input type="hidden" name="processor" value="<?php echo e(!is_null($list['devices'] -> processor) ? $list['devices'] -> processor -> processor : ' - '); ?>">
            <input type="hidden" name="memory1" value="<?php echo e(!is_null($list['devices'] -> memory1) ? $list['devices'] -> memory1 -> kind . ' ' . $list['devices'] -> memory1 -> size . ' GB' : ' - '); ?>">
            <input type="hidden" name="memory2" value="<?php echo e(!is_null($list['devices'] -> memory2) ? $list['devices'] -> memory2 -> kind . ' ' . $list['devices'] -> memory2 -> size . ' GB' : ' - '); ?>">
            <input type="hidden" name="hard_disk1" value="<?php echo e(!is_null($list['devices'] -> hard_disk1) ? $list['devices'] -> hard_disk1 -> kind . ' ' . $list['devices'] -> hard_disk1 -> size . ' GB' : ' - '); ?>">
            <input type="hidden" name="hard_disk2" value="<?php echo e(!is_null($list['devices'] -> hard_disk2) ? $list['devices'] -> hard_disk2 -> kind . ' ' . $list['devices'] -> hard_disk2 -> size . ' GB' : ' - '); ?>">

            <button type="submit" class="btn btn-dark mt-3" style="width: 50%">تصدير إلى اكسل <i class="fa fa-file-excel-o"></i></button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\ITAMS\resources\views/dates/index.blade.php ENDPATH**/ ?>