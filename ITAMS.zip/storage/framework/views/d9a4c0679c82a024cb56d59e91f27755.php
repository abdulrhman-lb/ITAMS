

<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
    <div class="container alert alert-warning" role="alert">
        <?php echo e(session()->get('message')); ?>

    </div> 
<?php endif; ?>
<div class="container" >
    <div class="row justify-content-center mb-3">
        <form action="<?php echo e(route('device_search')); ?>" method="post">   
            <?php echo csrf_field(); ?>
            <div class="accordion" id="accordionPanelsStayOpenExample">
                <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
                    <div class="fw-bold text-center">قائمة الأجهزة <?php echo e(' - ' . (Auth::user()->role == '1'  ? 'كل الفروع' : 'فرع ' . Auth::user()->branch->branch)); ?></div>
                </button>
                </h2>
                <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse">
                    <div class="accordion-body">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row text-center">
                                        <div class="col">
                                            <div class="row mb-3">
                                                <label for="branch_id" class="col-md-4 col-form-label text-center">الفرع</label>
                                                <div class="col-md-8">
                                                    <select class="form-select" id="branch_id" name="branch_id">
                                                        <option value="">-</option>
                                                        <?php $__currentLoopData = $list['branches']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($branch -> id); ?>" <?php echo e($branch -> id == $list['search_branch'] ? 'selected' : ''); ?>><?php echo e($branch -> branch); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label for="class_id" class="col-md-4 col-form-label text-center">التصنيف</label>
                                                <div class="col-md-8">
                                                    <select class="form-select" id="class_id" name="class_id">
                                                        <option value="">-</option>
                                                            <?php $__currentLoopData = $list['classes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($class -> id); ?>" <?php echo e($class -> id == $list['search_class'] ? 'selected' : ''); ?>><?php echo e($class -> class); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label for="status_id" class="col-md-4 col-form-label text-center">الحالة الفنية</label>
                                                <div class="col-md-8">
                                                    <select class="form-select" id="status_id" name="status_id">
                                                        <option value="">-</option>
                                                        <?php $__currentLoopData = $list['statuses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($status -> id); ?>" <?php echo e($status -> id == $list['search_status'] ? 'selected' : ''); ?>><?php echo e($status -> status); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
            
                                        <div class="col">
                                            <div class="row mb-3">
                                                <label for="sub_branch_id" class="col-md-3 col-form-label text-md-start">الشعبة</label>
                                                <div class="col-md-8">
                                                    <select class="form-select" id="sub_branch_id" name="sub_branch_id">
                                                        <option value="">-</option>
                                                        <?php $__currentLoopData = $list['sub_branches']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($sub_branch -> id); ?>" <?php echo e($sub_branch -> id == $list['search_sub_branch'] ? 'selected' : ''); ?>><?php echo e($sub_branch -> sub_branch .  ' - ' . $sub_branch -> sub_branch_en); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label for="category_id" class="col-md-3 col-form-label text-md-start">الصنف</label>
                                                <div class="col-md-8">
                                                    <select class="form-select" id="category_id" name="category_id">
                                                        <option value="">-</option>
                                                        <?php $__currentLoopData = $list['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($category -> id); ?>" <?php echo e($category -> id == $list['search_category'] ? 'selected' : ''); ?>><?php echo e($category -> category); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label for="serial" class="col-md-3 col-form-label text-md-start">S/N</label>
                                                <div class="col-md-8">
                                                    <input id="serial" type="text" class="form-control" name="serial" value="<?php echo e($list['search_serial_number']); ?>">
                                                </div>
                                            </div>
                                        </div>
            
                                        <div class="col ">
                                            <div class="row mb-3">
                                                <label for="department_id" class="col-md-3 col-form-label text-md-start">القسم</label>
                                                <div class="col-md-8">
                                                    <select class="form-select" id="department_id" name="department_id">
                                                        <option value="">-</option>
                                                        <?php $__currentLoopData = $list['departments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($department -> id); ?>" <?php echo e($department -> id == $list['search_department'] ? 'selected' : ''); ?>><?php echo e($department -> department); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label for="model_id" class="col-md-3 col-form-label text-md-start">الموديل</label>
                                                <div class="col-md-8">
                                                    <select class="form-select" id="model_id" name="model_id">
                                                        <option value="">-</option>
                                                        <?php $__currentLoopData = $list['models']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($model -> id); ?>" <?php echo e($model -> id == $list['search_model'] ? 'selected' : ''); ?>><?php echo e($model -> model); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <div class="col-md-12 offset-md-1">
                                                    <button type="submit" name="search" id="search" class="btn btn-dark" >تصفية</button>
                                                    <button type="submit" name="clear" id="cancel" class="btn btn-dark" >مسح</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div class="row justify-content-center mb-3 mt-3">
        <table class="table table-bordered ">
            <tr>
                <th class="centered-content">#</th>
                <th class="centered-content">صورة</th>
                <th class="centered-content">الصنف</th>
                <th class="centered-content">الموديل</th>
                <th class="centered-content">S/N</th>
                <th class="centered-content">اسم المستلم</th>
                <th class="centered-content" colspan="2"><a href="device/create"><button type="button" class="btn btn-dark my-1">إضافة جديدة  <i class="fa fa-plus-square"></i></button></a></th>
            </tr>
            <?php
                $count = 0;
            ?>
            <?php $__currentLoopData = $list['devices']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
                <tr class="pt-3 ">
                    <?php
                        $count++;
                        $image = '';
                        if (($device -> model -> image) == '' ) {
                            $image = 'model/non.png';
                        } else {
                            $image = 'model/' . $device -> model -> image; 
                        }
                    ?> 
                    <td class="fw-bold centered-content"><?php echo e($count); ?></td>
                    <td class="centered-content" id="image">
                        <a href="/images/<?php echo e($image); ?>" data-lightbox="post-image" data-title="<?php echo e($device -> model -> model); ?>">
                            <img src="/images/<?php echo e($image); ?>" alt="<?php echo e($device -> model -> model); ?>" class="thumbnail img-pro-show"">
                        </a>
                    </td>
                    <td class="centered-content" id="category"><?php echo e($device -> category -> category); ?></td>
                    <td class="centered-content" id="model"><?php echo e($device -> model -> model); ?></td>
                    <td class="centered-content" id="serial_number"><?php echo e($device -> serial_number); ?></td>
                    <?php
                        if (is_null($device -> employee)) {
                            $full_name = ' - ';
                        } else {
                            $full_name = $device -> employee -> full_name;
                        }
                    ?>
                    <td class="centered-content" id="full_name"><?php echo e($full_name); ?></td>
                    <td class="centered-content">
                    <form action="/device/<?php echo e($device -> id); ?>" method="POST">   
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("DELETE"); ?>
                        <a href="/device/<?php echo e($device -> id); ?>"><button type="button" class="btn btn-secondary my-1"><i class="fa fa-eye"></i></button></a>
                        <a href="/device/<?php echo e($device -> id); ?>/edit"><button type="button" class="btn btn-secondary my-1"><i class="fa fa-edit"></i></button></a>
                        <button type="submit" class="btn btn-secondary my-1" onclick ="return confirm('هل تريد بالتأكيد حذف هذا الموظف ؟')"><i class="fa fa-trash"></i></button>  
                        <a href="<?php echo e(route('dates',['id='.$device -> id,'branch_id='.$device -> branch_id,'back=0'])); ?>"><button type="button" title="استلام وتسليم" class="btn btn-secondary my-1"><i class="fa fa-retweet"></i><span class="badge"></span></button></a>
                    </form>  
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\ITAMS\resources\views/device/index.blade.php ENDPATH**/ ?>