<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
    <div class="container alert alert-warning" role="alert">
        <?php echo e(session()->get('message')); ?>

    </div> 
<?php endif; ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header text-center p-4 fw-bold">نظام إدارة أصول تجهيزات تقانة المعلومات</div>
                <div class="card-body">
                    <img src="images/itams.png" class="text-center rounded img-fluid p-5" alt="...">
                </div>
            </div>
        </div>
    </div>
</div>
  <div class="text-center ">
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\ITAMS\resources\views/welcome.blade.php ENDPATH**/ ?>