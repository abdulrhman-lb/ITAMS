<footer class="bg-danger text-lg-start bottom-0">
    <div class="text-light text-center p-3 bottom-0" style="background-color: rgba(32, 36, 40, 1); ">
      <h6>جميع الحقوق محفوظة</h6>
      <a class="text-light"></a>
    </div>
</footer>